<header>
  
    <div class="container">

        <nav class="breadcrumb is-left" aria-label="breadcrumbs">

            <ul>

                <li><a href="index.php">Home</a></li>

                <li><a href="handoverNotes.php">Handovers</a></li>

                <li><a href="action_items.php">Actions</a></li>

                <li><a href="createReportform.php">Create Report</a></li>

                <li><a href="./teams_sections.php">Sections & Teams</a></li>

            </ul>

        </nav>

        <div class="content">

            <h1 class="title is-2">Team Handover</h1>

            <p class="subtitle is-4">Effectively manage your team or crew's shift handovers!</p>
            <div class="block"></div>
        </div>
        

    </div>
</header>